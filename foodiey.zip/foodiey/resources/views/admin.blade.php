<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="favicon.png" type="image/x-icon"/>
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon"/>
    <title>FOODIEY</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
        crossorigin="anonymous">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="http://www.shieldui.com/shared/components/latest/css/light/all.min.css" />
</head>
<style>
    @keyframes swing {
  0% {
    transform: rotate(0deg);
  }
  10% {
    transform: rotate(10deg);
  }
  30% {
    transform: rotate(0deg);
  }
  40% {
    transform: rotate(-10deg);
  }
  50% {
    transform: rotate(0deg);
  }
  60% {
    transform: rotate(5deg);
  }
  70% {
    transform: rotate(0deg);
  }
  80% {
    transform: rotate(-5deg);
  }
  100% {
    transform: rotate(0deg);
  }
}

@keyframes sonar {
  0% {
    transform: scale(0.9);
    opacity: 1;
  }
  100% {
    transform: scale(2);
    opacity: 0;
  }
}
body {
  font-size: 0.9rem;
}
.page-wrapper .sidebar-wrapper,
.sidebar-wrapper .sidebar-brand > a,
.sidebar-wrapper .sidebar-dropdown > a:after,
.sidebar-wrapper .sidebar-menu .sidebar-dropdown .sidebar-submenu li a:before,
.sidebar-wrapper ul li a i,
.page-wrapper .page-content,
.sidebar-wrapper .sidebar-search input.search-menu,
.sidebar-wrapper .sidebar-search .input-group-text,
.sidebar-wrapper .sidebar-menu ul li a,
#show-sidebar,
#close-sidebar {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -ms-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}

/*----------------page-wrapper----------------*/

.page-wrapper {
  height: 100vh;
}

.page-wrapper .theme {
  width: 40px;
  height: 40px;
  display: inline-block;
  border-radius: 4px;
  margin: 2px;
}

.page-wrapper .theme.chiller-theme {
  background: #1e2229;
}

/*----------------toggeled sidebar----------------*/

.page-wrapper.toggled .sidebar-wrapper {
  left: 0px;
}

@media screen and (min-width: 768px) {
  .page-wrapper.toggled .page-content {
    padding-left: 300px;
  }
}
/*----------------show sidebar button----------------*/
#show-sidebar {
  position: fixed;
  left: 0;
  top: 10px;
  border-radius: 0 4px 4px 0px;
  width: 35px;
  transition-delay: 0.3s;
}
.page-wrapper.toggled #show-sidebar {
  left: -40px;
}
/*----------------sidebar-wrapper----------------*/

.sidebar-wrapper {
  width: 260px;
  height: 100%;
  max-height: 100%;
  position: fixed;
  top: 0;
  left: -300px;
  z-index: 999;
}

.sidebar-wrapper ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.sidebar-wrapper a {
  text-decoration: none;
}

/*----------------sidebar-content----------------*/

.sidebar-content {
  max-height: calc(100% - 30px);
  height: calc(100% - 30px);
  overflow-y: auto;
  position: relative;
}

.sidebar-content.desktop {
  overflow-y: hidden;
}

/*--------------------sidebar-brand----------------------*/

.sidebar-wrapper .sidebar-brand {
  padding: 10px 20px;
  display: flex;
  align-items: center;
}

.sidebar-wrapper .sidebar-brand > a {
  text-transform: uppercase;
  font-weight: bold;
  flex-grow: 1;
}

.sidebar-wrapper .sidebar-brand #close-sidebar {
  cursor: pointer;
  font-size: 20px;
}
/*--------------------sidebar-header----------------------*/

.sidebar-wrapper .sidebar-header {
  padding: 20px;
  overflow: hidden;
}

.sidebar-wrapper .sidebar-header .user-pic {
  float: left;
  width: 60px;
  padding: 2px;
  border-radius: 12px;
  margin-right: 15px;
  overflow: hidden;
}

.sidebar-wrapper .sidebar-header .user-pic img {
  object-fit: cover;
  height: 100%;
  width: 100%;
}

.sidebar-wrapper .sidebar-header .user-info {
  float: left;
}

.sidebar-wrapper .sidebar-header .user-info > span {
  display: block;
}

.sidebar-wrapper .sidebar-header .user-info .user-role {
  font-size: 12px;
}

.sidebar-wrapper .sidebar-header .user-info .user-status {
  font-size: 11px;
  margin-top: 4px;
}

.sidebar-wrapper .sidebar-header .user-info .user-status i {
  font-size: 8px;
  margin-right: 4px;
  color: #5cb85c;
}

/*-----------------------sidebar-search------------------------*/

.sidebar-wrapper .sidebar-search > div {
  padding: 10px 20px;
}

/*----------------------sidebar-menu-------------------------*/

.sidebar-wrapper .sidebar-menu {
  padding-bottom: 10px;
}

.sidebar-wrapper .sidebar-menu .header-menu span {
  font-weight: bold;
  font-size: 14px;
  padding: 15px 20px 5px 20px;
  display: inline-block;
}

.sidebar-wrapper .sidebar-menu ul li a {
  display: inline-block;
  width: 100%;
  text-decoration: none;
  position: relative;
  padding: 8px 30px 8px 20px;
}

.sidebar-wrapper .sidebar-menu ul li a i {
  margin-right: 10px;
  font-size: 12px;
  width: 30px;
  height: 30px;
  line-height: 30px;
  text-align: center;
  border-radius: 4px;
}

.sidebar-wrapper .sidebar-menu ul li a:hover > i::before {
  display: inline-block;
  animation: swing ease-in-out 0.5s 1 alternate;
}

.sidebar-wrapper .sidebar-menu .sidebar-dropdown > a:after {
  font-family: "Font Awesome 5 Free";
  font-weight: 900;
  content: "\f105";
  font-style: normal;
  display: inline-block;
  font-style: normal;
  font-variant: normal;
  text-rendering: auto;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  background: 0 0;
  position: absolute;
  right: 15px;
  top: 14px;
}

.sidebar-wrapper .sidebar-menu .sidebar-dropdown .sidebar-submenu ul {
  padding: 5px 0;
}

.sidebar-wrapper .sidebar-menu .sidebar-dropdown .sidebar-submenu li {
  padding-left: 25px;
  font-size: 13px;
}

.sidebar-wrapper .sidebar-menu .sidebar-dropdown .sidebar-submenu li a:before {
  content: "\f111";
  font-family: "Font Awesome 5 Free";
  font-weight: 400;
  font-style: normal;
  display: inline-block;
  text-align: center;
  text-decoration: none;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  margin-right: 10px;
  font-size: 8px;
}

.sidebar-wrapper .sidebar-menu ul li a span.label,
.sidebar-wrapper .sidebar-menu ul li a span.badge {
  float: right;
  margin-top: 8px;
  margin-left: 5px;
}

.sidebar-wrapper .sidebar-menu .sidebar-dropdown .sidebar-submenu li a .badge,
.sidebar-wrapper .sidebar-menu .sidebar-dropdown .sidebar-submenu li a .label {
  float: right;
  margin-top: 0px;
}

.sidebar-wrapper .sidebar-menu .sidebar-submenu {
  display: none;
}

.sidebar-wrapper .sidebar-menu .sidebar-dropdown.active > a:after {
  transform: rotate(90deg);
  right: 17px;
}

/*--------------------------side-footer------------------------------*/

.sidebar-footer {
  position: absolute;
  width: 100%;
  bottom: 0;
  display: flex;
}

.sidebar-footer > a {
  flex-grow: 1;
  text-align: center;
  height: 30px;
  line-height: 30px;
  position: relative;
}

.sidebar-footer > a .notification {
  position: absolute;
  top: 0;
}

.badge-sonar {
  display: inline-block;
  background: #980303;
  border-radius: 50%;
  height: 8px;
  width: 8px;
  position: absolute;
  top: 0;
}

.badge-sonar:after {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  border: 2px solid #980303;
  opacity: 0;
  border-radius: 50%;
  width: 100%;
  height: 100%;
  animation: sonar 1.5s infinite;
}

/*--------------------------page-content-----------------------------*/

.page-wrapper .page-content {
  display: inline-block;
  width: 100%;
  padding-left: 0px;
  padding-top: 20px;
  background: #E0EBF0;
}

.page-wrapper .page-content > div {
  padding: 20px 40px;
}

.page-wrapper .page-content {
  overflow-x: hidden;
}

/*------scroll bar---------------------*/

::-webkit-scrollbar {
  width: 5px;
  height: 7px;
}
::-webkit-scrollbar-button {
  width: 0px;
  height: 0px;
}
::-webkit-scrollbar-thumb {
  background: #525965;
  border: 0px none #ffffff;
  border-radius: 0px;
}
::-webkit-scrollbar-thumb:hover {
  background: #525965;
}
::-webkit-scrollbar-thumb:active {
  background: #525965;
}
::-webkit-scrollbar-track {
  background: transparent;
  border: 0px none #ffffff;
  border-radius: 50px;
}
::-webkit-scrollbar-track:hover {
  background: transparent;
}
::-webkit-scrollbar-track:active {
  background: transparent;
}
::-webkit-scrollbar-corner {
  background: transparent;
}


/*-----------------------------chiller-theme-------------------------------------------------*/

.chiller-theme .sidebar-wrapper {
    background: #31353D;
}

.chiller-theme .sidebar-wrapper .sidebar-header,
.chiller-theme .sidebar-wrapper .sidebar-search,
.chiller-theme .sidebar-wrapper .sidebar-menu {
    border-top: 1px solid #3a3f48;
}

.chiller-theme .sidebar-wrapper .sidebar-search input.search-menu,
.chiller-theme .sidebar-wrapper .sidebar-search .input-group-text {
    border-color: transparent;
    box-shadow: none;
}

.chiller-theme .sidebar-wrapper .sidebar-header .user-info .user-role,
.chiller-theme .sidebar-wrapper .sidebar-header .user-info .user-status,
.chiller-theme .sidebar-wrapper .sidebar-search input.search-menu,
.chiller-theme .sidebar-wrapper .sidebar-search .input-group-text,
.chiller-theme .sidebar-wrapper .sidebar-brand>a,
.chiller-theme .sidebar-wrapper .sidebar-menu ul li a,
.chiller-theme .sidebar-footer>a {
    color: #818896;
}

.chiller-theme .sidebar-wrapper .sidebar-menu ul li:hover>a,
.chiller-theme .sidebar-wrapper .sidebar-menu .sidebar-dropdown.active>a,
.chiller-theme .sidebar-wrapper .sidebar-header .user-info,
.chiller-theme .sidebar-wrapper .sidebar-brand>a:hover,
.chiller-theme .sidebar-footer>a:hover i {
    color: #b8bfce;
}

.page-wrapper.chiller-theme.toggled #close-sidebar {
    color: #bdbdbd;
}

.page-wrapper.chiller-theme.toggled #close-sidebar:hover {
    color: #ffffff;
}

.chiller-theme .sidebar-wrapper ul li:hover a i,
.chiller-theme .sidebar-wrapper .sidebar-dropdown .sidebar-submenu li a:hover:before,
.chiller-theme .sidebar-wrapper .sidebar-search input.search-menu:focus+span,
.chiller-theme .sidebar-wrapper .sidebar-menu .sidebar-dropdown.active a i {
    color: #16c7ff;
    text-shadow:0px 0px 10px rgba(22, 199, 255, 0.5);
}

.chiller-theme .sidebar-wrapper .sidebar-menu ul li a i,
.chiller-theme .sidebar-wrapper .sidebar-menu .sidebar-dropdown div,
.chiller-theme .sidebar-wrapper .sidebar-search input.search-menu,
.chiller-theme .sidebar-wrapper .sidebar-search .input-group-text {
    background: #3a3f48;
}

.chiller-theme .sidebar-wrapper .sidebar-menu .header-menu span {
    color: #6c7b88;
}

.chiller-theme .sidebar-footer {
    background: #3a3f48;
    box-shadow: 0px -1px 5px #282c33;
    border-top: 1px solid #464a52;
}

.chiller-theme .sidebar-footer>a:first-child {
    border-left: none;
}

.chiller-theme .sidebar-footer>a:last-child {
    border-right: none;
}

</style>
<body>
<div class="page-wrapper chiller-theme toggled">
  <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
    <i class="fas fa-bars"></i>
  </a>
  <nav id="sidebar" class="sidebar-wrapper">
    <div class="sidebar-content">
      <div class="sidebar-brand">
        <a href="#">Foodiey</a>
        <div id="close-sidebar">
          <i class="fas fa-times"></i>
        </div>
      </div>
      <div class="sidebar-header">
        <div class="user-pic">
          <img class="img-responsive img-rounded" src="admin.png"
            alt="User picture">
        </div>
        <div class="user-info">
          <span class="user-name">Innocent
            <strong>Magothe</strong>
          </span>
          <span class="user-role">Administrator</span>
          <span class="user-status">
            <i class="fa fa-circle"></i>
            <span>Online</span>
          </span>
        </div>
      </div>
      <!-- sidebar-header  -->
      <div class="sidebar-search">
        <div>
          <div class="input-group">
            <input type="text" class="form-control search-menu" placeholder="Search...">
            <div class="input-group-append">
              <span class="input-group-text">
                <i class="fa fa-search" aria-hidden="true"></i>
              </span>
            </div>
          </div>
        </div>
      </div>
      <!-- sidebar-search  -->
      <div class="sidebar-menu">
        <ul>
          <li class="header-menu">
            <span>General</span>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-tachometer-alt"></i>
              <span>Dashboard</span>
              <span class="badge badge-pill badge-warning">New</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#">Users
                    <span class="badge badge-pill badge-success">Pro</span>
                  </a>
                </li>
                <li>
                  <a href="#">Chefs</a>
                </li>
                <li>
                  <a href="#">Waiters</a>
                </li>
              </ul>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-shopping-cart"></i>
              <span>E-commerce</span>
              <span class="badge badge-pill badge-danger">3</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#">Meals

                  </a>
                </li>
                <li>
                  <a href="#">Orders</a>
                </li>
                <li>
                  <a href="#">Payments</a>
                </li>
              </ul>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="far fa-gem"></i>
              <span>Components</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#">Add waiter</a>
                </li>
                <li>
                  <a href="#">Add chef</a>
                </li>
                <li>
                  <a href="#">Add meals</a>
                </li>
              </ul>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-chart-line"></i>
              <span>Charts</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#">Pie chart</a>
                </li>
                <li>
                  <a href="#">Line chart</a>
                </li>
                <li>
                  <a href="#">Bar chart</a>
                </li>
                <li>
                  <a href="#">Histogram</a>
                </li>
              </ul>
            </div>
          </li>
          <li class="sidebar-dropdown">
            <a href="#">
              <i class="fa fa-globe"></i>
              <span>Maps</span>
            </a>
            <div class="sidebar-submenu">
              <ul>
                <li>
                  <a href="#">Google maps</a>
                </li>
                <li>
                  <a href="#">Open street map</a>
                </li>
              </ul>
            </div>
          </li>
          <li class="header-menu">
            <span>Extra</span>
          </li>
          <li>
            <a href="#">
              <i class="fa fa-book"></i>
              <span>Documentation</span>
              <span class="badge badge-pill badge-primary">Beta</span>
            </a>
          </li>
          <li>
            <a href="#">
              <i class="fa fa-calendar"></i>
              <span>Calendar</span>
            </a>
          </li>
          <li>
            <a href="#">
              <i class="fa fa-folder"></i>
              <span>Examples</span>
            </a>
          </li>
        </ul>
      </div>
      <!-- sidebar-menu  -->
    </div>
    <!-- sidebar-content  -->
    <div class="sidebar-footer">
      <a href="#">
        <i class="fa fa-bell"></i>
        <span class="badge badge-pill badge-warning notification">3</span>
      </a>
      <a href="#">
        <i class="fa fa-envelope"></i>
        <span class="badge badge-pill badge-success notification">7</span>
      </a>
      <a href="#">
        <i class="fa fa-cog"></i>
        <span class="badge-sonar"></span>
      </a>
      <a href="#">
        <i class="fa fa-power-off"></i>
      </a>
    </div>
  </nav>
  <!-- sidebar-wrapper  -->



  <main class="page-content">
    <div class="container-fluid">
      <h2>FOODIEY</h2>
      <hr>
      <div>
  <h4 class="mb-4 text-muted">Dashboard </h4>

  <div class="row">

    <div class="col-md-6 col-lg-3 mb-4">
      <div class="card border-0 rounded-0">
        <div class="card-body">
          <div class="card-innerBody d-flex align-items-center">
            <div class="card-icon text-light">
              <i class="fas fa-dollar-sign" aria-hidden="true" style='font-size:48px;color:#BFE1F1'></i>
            </div>
            <div class="ml-auto">
              <p class="card-label text-right text-muted">Revenue</p>
              <h4 class="card-text text-right ">$ 199,099</h4>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex ">
          <small class="text-muted">Since last month</small>
          <small class="text-success ml-auto">
            <i class="fa fa-caret-up" aria-hidden="true" ></i>
            5,35%
          </small>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-3 mb-4">
      <div class="card border-0 rounded-0">
        <div class="card-body">
          <div class="card-innerBody d-flex align-items-center">
            <div class="card-icon text-light">
              <i class="fa fa-shopping-cart" aria-hidden="true" style='font-size:48px;color:#BFE1F1'></i>
            </div>
            <div class="ml-auto">
              <p class="card-label text-right text-muted">Orders</p>
              <h4 class="card-text text-right ">2,200</h4>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex ">
          <small class="text-muted">Since last month</small>
          <small class="text-success ml-auto">
            <i class="fa fa-caret-up" aria-hidden="true"></i>
            8,66%
          </small>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-3 mb-4">
      <div class="card border-0 rounded-0">
        <div class="card-body">
          <div class="card-innerBody d-flex align-items-center">
            <div class="card-icon text-light">
              <i class="fa fa-users" aria-hidden="true" style='font-size:48px;color:#BFE1F1'></i>
            </div>
            <div class="ml-auto">
              <p class="card-label text-right text-muted">Visitors</p>
              <h4 class="card-text text-right ">702,258</h4>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex ">
          <small class="text-muted">Since last month</small>
          <small class="text-danger ml-auto">
            <i class="fa fa-caret-down" aria-hidden="true"></i>
            2,81%
          </small>
        </div>
      </div>
    </div>

    <div class="col-md-6 col-lg-3 mb-4">
      <div class="card border-0 rounded-0">
        <div class="card-body">
          <div class="card-innerBody d-flex align-items-center">
            <div class="card-icon text-light">
              <i class="fa fa-heartbeat" aria-hidden="true" style='font-size:48px;color:#BFE1F1'></i>
            </div>
            <div class="ml-auto">
              <p class="card-label text-right text-muted">Followers</p>
              <h4 class="card-text text-right "> +50K</h4>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex ">
          <small class="text-muted">Since last month</small>
          <small class="text-success ml-auto">
            <i class="fa fa-caret-up" aria-hidden="true"></i>
            1,74%
          </small>
        </div>
      </div>
    </div>

  </div>


  <div class="row">
    <div class="col-12 col-xl-6 mb-4 align-items-stretch">
      <div class="card h-100 border-0 rounded-0">
        <div class="card-title mb-1 p-3 d-flex">
          <h6>Chart Doughnut</h6>
          <a class="btn ml-auto p-0 text-lightning"> <i class="fas fa-ellipsis-h"></i> </a>
        </div>
        <div class="card-body">
          <div class="chart-container d-flex h-100 align-items-center justify-content-center" style="position: relative;">
            <div id="myBar"></div>
          </div>
        </div>
        <div class="card-footer">
          <div class="legend d-flex just">
            <div class="flex-fill text-center"><span class="d-inline-block rounded-circle mr-2"
                style="background: #5b6582;"></span><small>HTML</small></div>
            <div class="flex-fill text-center"><span class="d-inline-block rounded-circle mr-2"
                style="background: #98a4c7;"></span><small>CSS</small></div>
            <div class="flex-fill text-center"><span class="d-inline-block rounded-circle mr-2"
                style="background: #36a2eb;"></span><small>Javascript</small></div>
          </div>

        </div>
      </div>
    </div>

    <div class="col-12 col-xl-6 mb-4 align-items-stretch">
      <div class="card h-100 border-0 rounded-0">
        <div class="card-title mb-1 p-3 d-flex">
          <h6>Chart Doughnut</h6>
          <a class="btn ml-auto p-0 text-lightning"> <i class="fas fa-ellipsis-h"></i> </a>
        </div>
        <div class="card-body">
          <div class="chart-container d-flex h-100 align-items-center justify-content-center" style="position: relative;">
          <canvas id="myChart" width="400" height="400"></canvas>
          </div>
        </div>
        <div class="card-footer">
          <div class="legend d-flex just">
            <div class="flex-fill text-center"><span class="d-inline-block rounded-circle mr-2"
                style="background: #5b6582;"></span><small>HTML</small></div>
            <div class="flex-fill text-center"><span class="d-inline-block rounded-circle mr-2"
                style="background: #98a4c7;"></span><small>CSS</small></div>
            <div class="flex-fill text-center"><span class="d-inline-block rounded-circle mr-2"
                style="background: #36a2eb;"></span><small>Javascript</small></div>
          </div>

        </div>
      </div>
    </div>
    
    <div class="col-12 col-xl-4 mb-4 align-items-stretch">
      <div class="card h-100 border-0 rounded-0">
        <div class="card-title mb-1 p-3 d-flex">
          <h6>Chart Doughnut</h6>
          <a class="btn ml-auto p-0 text-lightning"> <i class="fas fa-ellipsis-h"></i> </a>
        </div>
        <div class="card-body">
          <div class="chart-container d-flex h-100 align-items-center justify-content-center" style="position: relative;">
          <div id="piechart"></div>
          </div>
        </div>
        <div class="card-footer">
          <div class="legend d-flex just">
            <div class="flex-fill text-center"><span class="d-inline-block rounded-circle mr-2"
                style="background: #5b6582;"></span><small>HTML</small></div>
            <div class="flex-fill text-center"><span class="d-inline-block rounded-circle mr-2"
                style="background: #98a4c7;"></span><small>CSS</small></div>
            <div class="flex-fill text-center"><span class="d-inline-block rounded-circle mr-2"
                style="background: #36a2eb;"></span><small>Javascript</small></div>
          </div>

        </div>
      </div>
    </div>

    <div class="col-12 col-xl-8 mb-4 align-items-stretch">
      <div class="card h-100 border-0 rounded-0">
        <div class="card-title mb-1 p-3 d-flex">
          <h6>Purchases</h6>
          <a class="btn ml-auto p-0 text-lightning"> <i class="fas fa-ellipsis-h"></i> </a>
        </div>
        <div class="card-body">
          <div class="table-responsive-md">
            <div class="table-responsive">
              <table class="table ">
                <thead>
                  <tr>
                    <th style="width:40%;">Product</th>
                    <th class="number">Price</th>
                    <th style="width:20%;">Date</th>
                    <th style="width:20%;">State</th>
                    <th class="actions" style="width:5%;"></th>
                  </tr>
                </thead>
                <tbody class="no-border-x">
                  <tr>
                    <td>Sony Xperia M4</td>
                    <td class="number">$149</td>
                    <td>Aug 23, 2018</td>
                    <td class="text-success">Completed</td>
                    <td class="actions"><a class="icon" href="#"><i class="mdi mdi-plus-circle-o"></i></a></td>
                  </tr>
                  <tr>
                    <td>Apple iPhone 6</td>
                    <td class="number">$535</td>
                    <td>Aug 20, 2018</td>
                    <td class="text-success">Completed</td>
                    <td class="actions"><a class="icon" href="#"><i class="mdi mdi-plus-circle-o"></i></a></td>
                  </tr>
                  <tr>
                    <td>Samsung Galaxy S7</td>
                    <td class="number">$583</td>
                    <td>Aug 18, 2018</td>
                    <td class="text-warning">Pending</td>
                    <td class="actions"><a class="icon" href="#"><i class="mdi mdi-plus-circle-o"></i></a></td>
                  </tr>
                  <tr>
                    <td>HTC One M9</td>
                    <td class="number">$350</td>
                    <td>Aug 15, 2018</td>
                    <td class="text-warning">Pending</td>
                    <td class="actions"><a class="icon" href="#"><i class="mdi mdi-plus-circle-o"></i></a></td>
                  </tr>
                  <tr>
                    <td>Sony Xperia Z5</td>
                    <td class="number">$495</td>
                    <td>Aug 13, 2018</td>
                    <td class="text-danger">Cancelled</td>
                    <td class="actions"><a class="icon" href="#"><i class="mdi mdi-plus-circle-o"></i></a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>
    </div>

  </div>

</div>
    </div>

    <div>

  <h4 class="mb-4 text-muted">Forms </h4>

  <div class="row">
    <div class="col-md-12 col-lg-6 mb-4 align-items-stretch">
      <div class="card border-0 rounded-0 h-100">
        <div class="card-title mb-1 p-3">
          <h5>Basic Form</h5>
        </div>
        <div class="card-body">
          <form>
            <div class="form-group">
              <label for="exampleInputEmail1">Email address</label>
              <input type="email" class="form-control rounded-0" id="exampleInputEmail1" aria-describedby="emailHelp"
                placeholder="Enter email">
              <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Password</label>
              <input type="password" class="form-control rounded-0" id="exampleInputPassword1" placeholder="Password">
            </div>
            <div class="custom-control custom-checkbox my-1 mr-sm-2 mb-3">
              <input type="checkbox" class="custom-control-input" id="customControlInline">
              <label class="custom-control-label" for="customControlInline">Remember me</label>
            </div>
            <button type="button" class="btn btn-lightning rounded-0 mb-2 mr-2">Submit</button>
            <button type="button " class="btn btn-outline-lightning rounded-0 mb-2">Cancel</button>
          </form>
        </div>
      </div>
    </div>
    <div class="col-md-12 col-lg-6 mb-4 align-items-stretch">
      <div class="card border-0 rounded-0 h-100">
        <div class="card-title mb-1 p-3">
          <h5>Horizontal Form</h5>
        </div>
        <div class="card-body">
          <form>
            <div class="form-group row">
              <label for="husername" class="col-sm-2 col-form-label text-nowrap">Username</label>
              <div class="col-sm-10">
                <input type="text" class="form-control rounded-0" id="husername" aria-describedby="emailHelp"
                  placeholder="Username">
              </div>
            </div>
            <div class="form-group row">
              <label for="staticEmail" class="col-sm-2 col-form-label text-nowrap">Email</label>
              <div class="col-sm-10">
                <input type="email" class="form-control rounded-0" id="staticEmail" aria-describedby="emailHelp"
                  placeholder="Enter email">
              </div>
            </div>
            <div class="form-group row">
              <label for="inputPassword" class="col-sm-2 col-form-label text-nowrap">Password</label>
              <div class="col-sm-10">
                <input type="password" class="form-control rounded-0" id="inputPassword" placeholder="Password">
              </div>
            </div>
            <div class="form-group row">
              <label for="" class="col-sm-2 col-form-label "></label>
              <div class="col-sm-10">
                <div class="custom-control custom-checkbox my-1 mr-sm-2">
                  <input type="checkbox" class="custom-control-input" id="hcustomControlInline" checked>
                  <label class="custom-control-label" for="hcustomControlInline">Remember me</label>
                </div>
              </div>
            </div>
            <div class="form-group row">
              <label for="" class="col-sm-2 col-form-label"></label>
              <div class="col-sm-10 mb-3">
                <button type="button" class="btn btn-lightning rounded-0 mb-2 mr-2">Submit</button>
                <button type="button " class="btn btn-outline-lightning rounded-0 mb-2">Cancel</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12 mb-4 ">

      <div class="card border-0 rounded-0">
        <div class="card-title mb-1 p-3">
          <h5>Basic Form Elements</h5>
        </div>
        <div class="card-body">
          <form>
            <div class="form-group">
              <label for="exampleFormControlInput1">Email address</label>
              <input type="email" class="form-control  rounded-0" id="exampleFormControlInput1"
                placeholder="name@example.com">
            </div>
            <div class="form-group">
              <label>Custom file input</label>
              <div class="custom-file">
                <input type="file" class="custom-file-input" id="customFile">
                <label class="custom-file-label rounded-0" for="customFile">Choose file</label>
              </div>
            </div>
            <div class="form-group">
              <label for="exampleFormControlSelect1">Example select</label>
              <select class="form-control rounded-0" id="exampleFormControlSelect1">
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </select>
            </div>
            <div class="form-group">
              <label for="exampleFormControlSelect2">Example multiple select</label>
              <select multiple class="form-control rounded-0" id="exampleFormControlSelect2">
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </select>
            </div>
            <div class="form-group">
              <label for="exampleFormControlTextarea1">Example textarea</label>
              <textarea class="form-control rounded-0" id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>

            <div class="form-group">
              <button type="button" class="btn btn-lightning rounded-0 mb-2 mr-2">Submit</button>
              <button type="button " class="btn btn-outline-lightning rounded-0 mb-2">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div>

  <h4 class="text-muted mb-4">Tables </h4>

  <div class="row mb-4">

    <div class="col-md-12">
      <div class="card border-0 rounded-0">
        <div class="card-title mb-1 p-3">
          <h5>Basic table</h5>
        </div>
        <div class="card-body">
          <div class="table-responsive-md">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">First</th>
                  <th scope="col">Last</th>
                  <th scope="col">Handle</th>
                  <th scope="col">Status</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">1</th>
                  <td>Mark</td>
                  <td>Otto</td>
                  <td>@mdo</td>
                  <td>
                    <span class="badge badge-primary rounded-0 p-1">Fixed</span>
                  </td>
                  <td>
                    <a class="btn btn-sm btn-outline-lightning rounded-0 mr-2 ">
                      <i class="far fa-edit"></i>
                    </a>
                    <a class="btn btn-sm btn-outline-lightning rounded-0">
                      <i class="far fa-trash-alt"></i>
                    </a>
                  </td>
                </tr>
                <tr>
                  <th scope="row">2</th>
                  <td>Jacob</td>
                  <td>Thornton</td>
                  <td>@fat</td>
                  <td>
                    <span class="badge badge-warning rounded-0 p-1">In progress</span>
                  </td>
                  <td>
                    <a class="btn btn-sm btn-outline-lightning rounded-0 mr-2">
                      <i class="far fa-edit"></i>
                    </a>
                    <a class="btn btn-sm btn-outline-lightning rounded-0 ">
                      <i class="far fa-trash-alt"></i>
                    </a>
                  </td>
                </tr>
                <tr>
                  <th scope="row">3</th>
                  <td>Larry</td>
                  <td>the Bird</td>
                  <td>@twitter</td>
                  <td>
                    <span class="badge badge-success rounded-0 p-1">Completed</span>
                  </td>
                  <td>
                    <a class="btn btn-sm btn-outline-lightning rounded-0 mr-2">
                      <i class="far fa-edit"></i>
                    </a>
                    <a class="btn btn-sm btn-outline-lightning rounded-0">
                      <i class="far fa-trash-alt"></i>
                    </a>
                  </td>
                </tr>
                <tr>
                  <th scope="row">4</th>
                  <td>Jhon</td>
                  <td>Smith</td>
                  <td>@Instagram</td>
                  <td>
                    <span class="badge badge-danger rounded-0 p-1">Pending</span>
                  </td>
                  <td>
                    <a class="btn btn-sm btn-outline-lightning rounded-0 mr-2">
                      <i class="far fa-edit"></i>
                    </a>
                    <a class="btn btn-sm btn-outline-lightning rounded-0">
                      <i class="far fa-trash-alt"></i>
                    </a>
                  </td>
                </tr>
                <tr>
                  <th scope="row">5</th>
                  <td>David</td>
                  <td>the Mad</td>
                  <td>@Facebook</td>
                  <td>
                    <span class="badge badge-dark rounded-0 p-1">Created</span>
                  </td>
                  <td>
                    <a class="btn btn-sm btn-outline-lightning rounded-0 mr-2">
                      <i class="far fa-edit"></i>
                    </a>
                    <a class="btn btn-sm btn-outline-lightning rounded-0">
                      <i class="far fa-trash-alt"></i>
                    </a>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

        </div>
      </div>

    </div>
  </div>

  <div class="row">

    <div class="col-md-12 mb-4">

      <div class="card border-0 rounded-0">
        <div class="card-title mb-1 p-3">
          <h5>Striped table</h5>
        </div>
        <div class="card-body">
          <div class="table-responsive-md">
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>Task</th>
                    <th>Progress</th>
                    <th>Deadline</th>
                    <th >Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Lunar probe project</td>
                    <td class="align-middle">
                      <div class="progress" style="height: 3px;">
                        <div class="progress-bar bg-danger" style="width: 35% ;"></div>
                      </div>
                    </td>
                    <td>May 15, 2020</td>
                    <td >
                     <a class="btn btn-sm btn-outline-lightning rounded-0"><i class="fa fa-ban mr-1"></i>Cancel</a>
                    </td>
                  </tr>
                  <tr>
                    <td>Dream successful plan</td>
                    <td class="align-middle">
                      <div class="progress" style="height: 3px;">
                        <div class="progress-bar bg-warning" style="width: 50%; "></div>
                      </div>
                    </td>
                    <td>July 1, 2020</td>
                    <td >
                     <a class="btn btn-sm btn-outline-lightning rounded-0"><i class="fa fa-ban mr-1"></i>Cancel</a>
                    </td>
                  </tr>
                  <tr>
                    <td>Office automatization</td>
                    <td class="align-middle">
                      <div class="progress" style="height: 3px;">
                        <div class="progress-bar bg-success" style="width: 100%; "></div>
                      </div>
                    </td>
                    <td>Apr 12, 2020</td>
                    <td >
                     <a class="btn btn-sm btn-outline-lightning rounded-0"><i class="fa fa-ban mr-1"></i>Cancel</a>
                    </td>
                  </tr>
                  <tr>
                    <td>The sun climbing plan</td>
                    <td class="align-middle">
                      <div class="progress" style="height: 3px;">
                        <div class="progress-bar bg-primary" style="width: 70%; "></div>
                      </div>
                    </td>
                    <td>Aug 9, 2020</td>
                    <td >
                     <a class="btn btn-sm btn-outline-lightning rounded-0"><i class="fa fa-ban mr-1"></i>Cancel</a>
                    </td>
                  </tr>
                  <tr>
                    <td>Open strategy</td>
                    <td class="align-middle">
                      <div class="progress" style="height: 3px;">
                        <div class="progress-bar bg-info" style="width: 85%; "></div>
                      </div>
                    </td>
                    <td>Apr 2, 2020</td>
                    <td >
                     <a class="btn btn-sm btn-outline-lightning rounded-0"><i class="fa fa-ban mr-1"></i>Cancel</a>
                    </td>
                  </tr>
                  <tr>
                    <td>Tantas earum numeris</td>
                    <td class="align-middle">
                      <div class="progress" style="height: 3px;">
                        <div class="progress-bar bg-dark" style="width: 50%; "></div>
                      </div>
                    </td>
                    <td>July 11, 2020</td>
                    <td >
                     <a class="btn btn-sm btn-outline-lightning rounded-0"><i class="fa fa-ban mr-1"></i>Cancel</a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>

  </div>
</div>





<div class="container-fluid">
  <div class="row pt-4">
    <div class="col-md-12 text-center mb-2">
      <small> © 2019 made with <i class="fa fa-heart text-danger" aria-hidden="true"></i> by <span
          class="text-secondary font-weight-bold">Innocent Magothe</span></small>
    </div>
    <div class="col-md-12 text-center mb-3">
      <a href="https://github.com/azouaoui-med" target="_blank"
        class="btn btn-sm bg-light text-dark shadow-sm rounded-circle text-light m-2"><i class="fab fa-github"></i></a>
      <a href="https://twitter.com/azouaoui_med" target="_blank"
        class="btn btn-sm bg-light text-dark shadow-sm rounded-circle text-light m-2"><i class="fab fa-twitter"></i></a>
      <a href="https://www.instagram.com/azouaoui_med/" target="_blank"
        class="btn btn-sm bg-light text-dark shadow-sm rounded-circle text-light m-2"><i
          class="fab fa-instagram"></i></a>
      <a href="https://www.linkedin.com/in/mohamed-azouaoui/" target="_blank"
        class="btn btn-sm bg-light text-dark shadow-sm rounded-circle text-light m-2"><i
          class="fab fa-linkedin-in"></i></a>
    </div>
    <div class="col-md-12 text-center">
      <iframe
        src="https://ghbtns.com/github-btn.html?user=azouaoui-med&repo=lightning-admin-angular&type=fork&count=true&size=small"
        frameborder="0" scrolling="0" width="80px" height="20px"></iframe>

      <iframe
        src="https://ghbtns.com/github-btn.html?user=azouaoui-med&repo=lightning-admin-angular&type=star&count=true&size=small"
        frameborder="0" scrolling="0" width="80px" height="20px"></iframe>
    </div>


  </div>

</div>

  </main>
  <!-- page-content" -->
</div>


<!-- page-wrapper -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.css"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.css"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"></script>
        <script type="text/javascript" src="http://www.shieldui.com/shared/components/latest/js/shieldui-all.min.js"></script>
    <script>
        jQuery(function ($) {

$(".sidebar-dropdown > a").click(function() {
$(".sidebar-submenu").slideUp(200);
if (
$(this)
  .parent()
  .hasClass("active")
) {
$(".sidebar-dropdown").removeClass("active");
$(this)
  .parent()
  .removeClass("active");
} else {
$(".sidebar-dropdown").removeClass("active");
$(this)
  .next(".sidebar-submenu")
  .slideDown(200);
$(this)
  .parent()
  .addClass("active");
}
});

$("#close-sidebar").click(function() {
$(".page-wrapper").removeClass("toggled");
});
$("#show-sidebar").click(function() {
$(".page-wrapper").addClass("toggled");
});




});




// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
  var data = google.visualization.arrayToDataTable([
  ['Task', 'Hours per Day'],
  ['Work', 8],
  ['Eat', 2],
  ['TV', 4],
  ['Gym', 2],
  ['Sleep', 14]
]);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'My Average Day', 'width':400, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}


var ctx = document.getElementById('myChart');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});

var ctx = document.getElementById('myBarChart');
var myBarChart = new Chart(ctx, {
    type: 'horizontalBar',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});
</script>
    
</body>
</html>